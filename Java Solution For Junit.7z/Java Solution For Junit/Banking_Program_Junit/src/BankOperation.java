



public class BankOperation 
{
	private int balance; 
	
	public BankOperation() 
	{
		balance = 0;
	}
	
	
	public int getbalance() 
	{
	return balance; 
	}
	
	public void withdraw(int amount) throws InsufficientFundsException 
	{ 
		if (amount > balance) 
	  
			throw new InsufficientFundsException("Insufficient Funds");
		
		else
		{	
			balance = balance - amount; 
			
		}
	}
	
	
	public void deposit(int amount)
	{ 
		
		
		balance = balance + amount; 
	}

}
