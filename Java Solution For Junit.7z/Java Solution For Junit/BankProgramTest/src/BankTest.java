import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.Assume;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class BankTest 
{
	
	
	static BankOperation customer ;
	
	// Method must be static
	@BeforeClass
	public static void TestDataSetUp()
	{
		System.out.println("Called Once  Before Any Test In The Class");
	//	Assume.assumeTrue(false);
	}
	 
	
	
	// Method must be static
	@AfterClass
	public static void TestDataCleanUp()
	{
		System.out.println("Called Once  After All Test In The Class"); 
	}
	
	
	
	
	@Before
	public void initialiseCustomer()
	{
		 customer = new BankOperation () ;		
	}
	
	
	
	
	
	@Test
	public void initialBalanceIsZeroTest()
	{
	
		assertEquals("Initial Balance is Not Zero",0,customer.getbalance());
		
		
	}
	
	
	
	
	
	@Test
	public void DepositTest()
	{
	
	customer.deposit(1000);
	assertEquals("Account balance is not correct ",1000,customer.getbalance());
	}
	
	
	
	
	
	//  Will Purposely Fail This Test
	//  @Ignore will  ignore the test case
	
	
	
	
	
	
	// Time in MiliSeconds
	@Ignore
	@Test(timeout=10)
	public void failtheTest()
	{
	
		assertEquals("Initial Balance is Not Zero",1,customer.getbalance());
		
		
	}
	
	
	
	
	
	
}
