import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;


public class ExceptionTest
{
	
	
	
/************  WIll Test That Method Is Going To Throw The Exception Or Not  ***************/
	
	
	@Test(expected = InsufficientFundsException.class)
	public void ValidateWithdrawExceptionTest() throws InsufficientFundsException
	{
		BankOperation customer = new BankOperation();
		customer.withdraw(1000);

	}
	
	
	
/************  Rule Can Help Us Teting The Exception Message  ***************/


	@Rule
	public ExpectedException thrown = ExpectedException.none();

	@Test
	public void ValidateWithdrawExceptionMessageTest() throws InsufficientFundsException
	{
		thrown.expect(InsufficientFundsException.class);
		thrown.expectMessage("Insufficient Funds");

		BankOperation customer = new BankOperation();
		customer.withdraw(5000);

	}
	

}
