import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import java.util.ArrayList;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;


public class SeleniumTest 
{
	
	
	
	 WebDriver driver;
	
		
	@Before                                                // Gets Executed Before Every Test
	public void initialiseBrowser()
	{
		 System.setProperty("webdriver.chrome.driver","D:/Selenium-Drivers/ChromeDriver/chromedriver.exe");		
	}
	
	
		
	@After   											// Gets Executed After Every Test
	public void TestCleanUp()
	{
		 driver.quit();	
	}
	
	
	
	@Test
	public void BrowserTest()
	{	
		 driver = new ChromeDriver ();
		 driver.manage().window().maximize();
		 driver.get("https://www.cricbuzz.com/");
		 
		 String title =driver.getTitle();	
		assertEquals(" Test DiD Not Pass ","Cricket Score, Schedule, Latest News, Stats & Videos | Cricbuzz.com",title);		
		
	}
	

}
