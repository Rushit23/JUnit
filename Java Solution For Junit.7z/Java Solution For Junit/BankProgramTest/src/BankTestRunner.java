


import java.util.List;

import org.junit.runner.Description;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

public class BankTestRunner 
{

	public static void main(String[] args)
	{
		
		Result result = JUnitCore.runClasses(BankTest.class);
		
		
		// Description Useful For Debugging
		
		Description obj =Description.createSuiteDescription(BankTest.class);

		obj.getClassName();
		obj.getDisplayName();
		obj.getMethodName();
		
		
		
		System.out.println("\n========================== From Results =============================");
		
		if(result.wasSuccessful())
		{
			
			System.out.println(" Run Count : " + result.getRunCount());
			System.out.println(" Run Time : " + result.getRunTime());
				
		}
		
		else
		{
			System.out.println(" Run Count : " + result.getFailureCount());
			System.out.println(" Run Count : " + result.getIgnoreCount());
		
		}
		
		List<Failure> fail = result.getFailures();
		
		for(Failure f : fail)
		{
			// Description Class
			
			Description d = f.getDescription();
			System.out.println("Class Name : " + d.getClassName());
			System.out.println("Display Name : " + d.getDisplayName());
			System.out.println("Method Name : " + d.getMethodName());
			
			System.out.println("Exception Message : " + f.getMessage());
			System.out.println("Stack Trace : " + f.getTrace());
			System.out.println("Test Header : " + f.getTestHeader());
			System.out.println("+++++++++++++++++++++++++++++++++++++++++++");
		}
		
				
		
		
	}

}
